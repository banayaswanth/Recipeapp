package com.hashmac.recipesapp

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.*
import com.google.firebase.ktx.Firebase
import com.hashmac.recipesapp.models.Recipe

class MapActivity : AppCompatActivity() {

    private lateinit var mMap: GoogleMap
    private lateinit var auth: FirebaseAuth
    private lateinit var database: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_map)

        auth = Firebase.auth
        database = FirebaseDatabase.getInstance().reference.child("Recipes")

        val mapFragment = supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync { googleMap ->
            mMap = googleMap
            // Enable zoom controls
            mMap.uiSettings.isZoomControlsEnabled = true
            // Load recipes' locations from Firebase
            loadRecipeLocations()
        }
    }

    private fun loadRecipeLocations() {
        val recipeListener = object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                for (recipeSnapshot in dataSnapshot.children) {
                    val recipe = recipeSnapshot.getValue(Recipe::class.java)
                    recipe?.let {
                        // Display recipe location on the map
                        displayRecipeLocation(it)
                    }
                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
                // Handle database error
            }
        }
        database.addListenerForSingleValueEvent(recipeListener)
    }

    private fun displayRecipeLocation(recipe: Recipe) {
        val location = LatLng(recipe.latitude!!, recipe.longitude!!)
        val marker = mMap.addMarker(MarkerOptions().position(location).title(recipe.name))
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(location, 10f))

        marker!!.tag = recipe.name // Attach recipe name as a tag to the marker

        mMap.setOnMarkerClickListener { clickedMarker ->
            val clickedRecipeName = clickedMarker.tag as? String // Retrieve the recipe name from the marker's tag
            clickedRecipeName?.let { name ->
                // Start AllRecipesActivity with the clicked recipe name
                val intent = AllRecipesActivity.newIntent(this@MapActivity, "search")
                intent.putExtra("query", name)
                startActivity(intent)
            }
            true // Return true to consume the click event
        }
    }
}
