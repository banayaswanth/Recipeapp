package com.hashmac.recipesapp

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.hashmac.recipesapp.adapters.RecipeAdapter
import com.hashmac.recipesapp.databinding.ActivityAllRecipesBinding
import com.hashmac.recipesapp.models.Recipe
import java.util.Collections
import java.util.Locale

class AllRecipesActivity : AppCompatActivity() {
    private var binding: ActivityAllRecipesBinding? = null
    private var reference: DatabaseReference? = null
    private var type: String? = null
    private var query: String? = null // Add a variable to hold the query string

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAllRecipesBinding.inflate(layoutInflater)
        setContentView(binding!!.root)

        reference = FirebaseDatabase.getInstance().getReference("Recipes")
        binding!!.rvRecipes.layoutManager = GridLayoutManager(this, 2)
        binding!!.rvRecipes.adapter = RecipeAdapter(this)
        type = intent.getStringExtra("type")
        query = intent.getStringExtra("query") // Retrieve the query string
    }

    override fun onResume() {
        super.onResume()
        if (type.equals("category", ignoreCase = true)) {
            filterByCategory()
        } else if (type.equals("search", ignoreCase = true) || (query.equals("nearbyRecipes", ignoreCase = true))) {
            loadByRecipes()
        } else {
            loadAllRecipes()
        }
    }

    private fun loadByRecipes() {
        // Use the query string obtained from intent extras
        reference!!.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val recipes: MutableList<Recipe?> = ArrayList()
                for (dataSnapshot in snapshot.children) {
                    val recipe = dataSnapshot.getValue(Recipe::class.java)
                    if (recipe!!.name?.lowercase(Locale.getDefault())!!.contains(
                            query!!.lowercase(
                                Locale.getDefault()
                            )
                        )
                    ) recipes.add(recipe)
                }
                val adapter = binding!!.rvRecipes.adapter as RecipeAdapter?
                adapter?.setRecipeList(recipes)
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("Error", error.message)
            }
        })
    }

    private fun loadAllRecipes() {
        reference!!.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val recipes: MutableList<Recipe?> = ArrayList()
                for (dataSnapshot in snapshot.children) {
                    val recipe = dataSnapshot.getValue(Recipe::class.java)
                    recipes.add(recipe)
                }
                Collections.shuffle(recipes)
                val adapter = binding!!.rvRecipes.adapter as RecipeAdapter?
                adapter?.setRecipeList(recipes)
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("Error", error.message)
            }
        })
    }

    private fun filterByCategory() {
        val category = intent.getStringExtra("category")
        reference!!.orderByChild("category").equalTo(category)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val recipes: MutableList<Recipe?> = ArrayList()
                    for (dataSnapshot in snapshot.children) {
                        val recipe = dataSnapshot.getValue(Recipe::class.java)
                        recipes.add(recipe)
                    }
                    val adapter = binding!!.rvRecipes.adapter as RecipeAdapter?
                    adapter?.setRecipeList(recipes)
                }

                override fun onCancelled(error: DatabaseError) {
                    Log.e("Error", error.message)
                }
            })
    }

    companion object {
        fun newIntent(context: Context, type: String): Intent {
            return Intent(context, AllRecipesActivity::class.java).apply {
                putExtra("type", type)
            }
        }
    }
}
