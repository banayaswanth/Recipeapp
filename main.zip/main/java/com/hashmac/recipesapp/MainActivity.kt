package com.hashmac.recipesapp

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.NavController
import androidx.navigation.Navigation
import androidx.navigation.ui.NavigationUI.setupWithNavController
import com.google.firebase.auth.FirebaseAuth
import com.hashmac.recipesapp.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var navController: NavController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        navController = Navigation.findNavController(this, R.id.nav_host_fragment_activity_main)
        setupWithNavController(binding.navView, navController)

        binding.floatingActionButton.setOnClickListener { view: View? ->
            if (FirebaseAuth.getInstance().currentUser == null) {
                Toast.makeText(this, "Please login to add recipe", Toast.LENGTH_SHORT).show()
            } else {
                startActivity(Intent(this@MainActivity, AddRecipeActivity::class.java))
            }
        }

        binding.anotherFloatingActionButton.setOnClickListener { view: View? ->
            // Replace MainActivity.this with your activity context
            val intent = Intent(this@MainActivity, MapActivity::class.java)
            startActivity(intent)
        }


    }
}
