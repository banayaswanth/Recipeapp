package com.hashmac.recipesapp.adapters

import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.hashmac.recipesapp.AllRecipesActivity
import com.hashmac.recipesapp.R
import com.hashmac.recipesapp.databinding.ItemCategoryBinding
import com.hashmac.recipesapp.models.Category

class CategoryAdapter : RecyclerView.Adapter<CategoryAdapter.CategoryHolder>() {
    private var categoryList: List<Category> = ArrayList()
    private val categoryImageMap: Map<String, Int> = mapOf(
        "Breakfast" to R.drawable.breakfast,
        "Lunch" to R.drawable.lunch,
        "Dinner" to R.drawable.dinner,
        "Dessert" to R.drawable.dessert,
        "Vegetarian" to R.drawable.vegeterian,
        "Italian" to R.drawable.italian,
        "Mexican" to R.drawable.mexician
        // Add more mappings as needed
    )

    fun setCategoryList(categories: List<Category>) {
        categoryList = categories
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CategoryHolder {
        return CategoryHolder(
            ItemCategoryBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: CategoryHolder, position: Int) {
        val category = categoryList[position]
        holder.bind(category)
    }

    override fun getItemCount(): Int {
        return categoryList.size
    }

    inner class CategoryHolder(private val binding: ItemCategoryBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(category: Category) {
            binding.tvName.text = category.name
            val context = binding.root.context
            val imageResId = categoryImageMap[category.name]
            imageResId?.let {
                Glide.with(context)
                    .load(it)
                    .centerCrop()
                    .placeholder(R.mipmap.ic_launcher)
                    .into(binding.imgBgCategory)
            }
            binding.root.setOnClickListener {
                val intent = Intent(context, AllRecipesActivity::class.java)
                intent.putExtra("type", "category")
                intent.putExtra("category", category.name)
                context.startActivity(intent)
            }
        }
    }
}
