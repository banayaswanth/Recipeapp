package com.hashmac.recipesapp.adapters

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.hashmac.recipesapp.R
import com.hashmac.recipesapp.RecipeDetailsActivity
import com.hashmac.recipesapp.databinding.ItemRecipeHorizontalBinding
import com.hashmac.recipesapp.models.Recipe

class HorizontalRecipeAdapter(private val context: Context) : RecyclerView.Adapter<HorizontalRecipeAdapter.RecipeHolder>() {
    private var recipeList: MutableList<Recipe> = mutableListOf()

    fun setRecipeList(recipeList: List<Recipe>) {
        this.recipeList.clear()
        this.recipeList.addAll(recipeList)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecipeHolder {
        val binding = ItemRecipeHorizontalBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return RecipeHolder(binding)
    }

    override fun onBindViewHolder(holder: RecipeHolder, position: Int) {
        val recipe = recipeList[position]
        holder.bind(recipe)
    }

    override fun getItemCount(): Int {
        return recipeList.size
    }

    inner class RecipeHolder(private val binding: ItemRecipeHorizontalBinding) : RecyclerView.ViewHolder(binding.root) {

        fun bind(recipe: Recipe) {
            Glide.with(context)
                .load(recipe.image)
                .centerCrop()
                .placeholder(R.mipmap.ic_launcher)
                .into(binding.bgImgRecipe)

            binding.tvRecipeName.text = recipe.name

            binding.root.setOnClickListener {
                val intent = Intent(context, RecipeDetailsActivity::class.java)
                intent.putExtra("recipe", recipe)
                context.startActivity(intent)
            }
        }
    }
}
