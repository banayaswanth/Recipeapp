package com.hashmac.recipesapp.adapters

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.hashmac.recipesapp.R
import com.hashmac.recipesapp.RecipeDetailsActivity
import com.hashmac.recipesapp.databinding.ItemRecipeBinding
import com.hashmac.recipesapp.models.Recipe

class RecipeAdapter(private val context: Context) :
    RecyclerView.Adapter<RecipeAdapter.RecipeHolder>() {

    private var recipeList: List<Recipe?> = ArrayList()

    fun setRecipeList(recipeList: List<Recipe?>) {
        this.recipeList = recipeList
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecipeHolder {
        val binding =
            ItemRecipeBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return RecipeHolder(binding)
    }

    override fun onBindViewHolder(holder: RecipeHolder, position: Int) {
        val recipe = recipeList[position]
        recipe?.let { holder.bind(it) }
    }

    override fun getItemCount(): Int {
        return recipeList.size
    }

    inner class RecipeHolder(private val binding: ItemRecipeBinding) :
        RecyclerView.ViewHolder(binding.root), View.OnClickListener {

        fun bind(recipe: Recipe) {
            binding.tvRecipeName.text = recipe.name
            Glide.with(context)
                .load(recipe.image)
                .centerCrop()
                .placeholder(R.mipmap.ic_launcher)
                .into(binding.bgImgRecipe)

            binding.root.setOnClickListener(this)
        }

        override fun onClick(view: View) {
            val position = adapterPosition
            if (position != RecyclerView.NO_POSITION) {
                val intent = Intent(context, RecipeDetailsActivity::class.java)
                intent.putExtra("recipe", recipeList[position])
                context.startActivity(intent)
            }
        }
    }
}