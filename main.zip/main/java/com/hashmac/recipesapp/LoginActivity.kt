package com.hashmac.recipesapp

import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.tasks.Task
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.AuthResult
import com.google.firebase.auth.FirebaseAuth
import com.hashmac.recipesapp.databinding.ActivityLoginBinding
import java.util.Objects


class LoginActivity : AppCompatActivity() {
    private var binding: ActivityLoginBinding? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding!!.root)
        binding!!.btnLogin.setOnClickListener { view: View? -> login() }

        binding!!.tvSignup.setOnClickListener { view: View? ->
            startActivity(
                Intent(
                    this,
                    SingUpActivity::class.java
                )
            )
        } // navigate to signup activity
    }

    private fun login() {
        val email = Objects.requireNonNull(binding!!.etEmail.text).toString().trim { it <= ' ' }
        val password =
            Objects.requireNonNull(binding!!.etPassword.text).toString().trim { it <= ' ' }
        // let's check if the email and password fields are empty
        if (email.isEmpty() || password.isEmpty()) {
            // if they are empty we will display a toast message to the user
            Toast.makeText(this, "Please enter your email and password", Toast.LENGTH_SHORT).show()
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(this, "Please enter a valid email address", Toast.LENGTH_SHORT).show()
        } else if (password.length < 6) {
            Toast.makeText(this, "Password must be at least 6 characters", Toast.LENGTH_SHORT)
                .show()
        } else {
            // here we perform the login operation
            // if the user is successfully logged in we will launch the MainActivity
            // Let's test our Firebase connection and login functionality
            // Our code works fine, but we can improve it.
            FirebaseApp.initializeApp(this)
            val auth = FirebaseAuth.getInstance()
            auth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener { task: Task<AuthResult?> ->
                    if (task.isSuccessful) {
                        Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show()
                        startActivity(
                            Intent(
                                this,
                                MainActivity::class.java
                            )
                        ) // Navigate to main activity
                        finish()
                    } else {
                        Toast.makeText(
                            this,
                            "Login failed: " + Objects.requireNonNull(task.exception)!!.message,
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
        }
    }
}