package com.hashmac.recipesapp

import android.app.ProgressDialog
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.ActivityInfo
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.google.android.gms.tasks.Task
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import com.hashmac.recipesapp.AddRecipeActivity
import com.hashmac.recipesapp.R
import com.hashmac.recipesapp.databinding.ActivityRecipeDetailsBinding
import com.hashmac.recipesapp.models.FavouriteRecipe
import com.hashmac.recipesapp.models.Recipe
import com.hashmac.recipesapp.room.RecipeRepository
import java.io.File

class RecipeDetailsActivity : AppCompatActivity(), SensorEventListener {

    private lateinit var binding: ActivityRecipeDetailsBinding
    private var recipe: Recipe? = null
    private var videoUri: Uri? = null
    private lateinit var sensorManager: SensorManager
    private var accelerometer: Sensor? = null
    private var magnetometer: Sensor? = null
    private var isGyroscopeActive = false
    private var isVideoPlaying = false
    private var lastPitch = 0f
    private var lastRoll = 0f
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRecipeDetailsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        magnetometer = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)

        init()
    }

    override fun onResume() {
        super.onResume()
        if (isGyroscopeActive) {
            accelerometer?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL) }
            magnetometer?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL) }
        }
    }


    override fun onPause() {
        super.onPause()
        sensorManager.unregisterListener(this)
    }

    private fun init() {
        recipe = intent.getSerializableExtra("recipe") as Recipe?
        recipe?.let { displayRecipeDetails(it) }
        setupUI()
    }

    private fun displayRecipeDetails(recipe: Recipe) {
        Log.d("TAG", recipe.toString())
        binding.apply {
            tvName.text = recipe.name
            tcCategory.text = recipe.category
            tvDescription.text = recipe.description
            tvCalories.text = String.format("%s Calories", recipe.calories)
            Glide.with(this@RecipeDetailsActivity)
                .load(recipe.image)
                .centerCrop()
                .placeholder(R.mipmap.ic_launcher)
                .into(imgRecipe)
        }

        if (!recipe.videoUrl.isNullOrEmpty()) {
            binding.videoView.visibility = View.VISIBLE
            fetchVideoFromFirebaseStorage(recipe.videoUrl!!)
        } else {
            binding.videoView.visibility = View.GONE
        }
    }

    private fun setupUI() {
        recipe?.let { currentRecipe ->
            binding.apply {
                if (currentRecipe.authorId == FirebaseAuth.getInstance().uid) {
                    imgEdit.visibility = View.VISIBLE
                    btnDelete.visibility = View.VISIBLE
                } else {
                    imgEdit.visibility = View.GONE
                    btnDelete.visibility = View.GONE
                }

                imgEdit.setOnClickListener {
                    val intent = Intent(root.context, AddRecipeActivity::class.java)
                    intent.putExtra("recipe", currentRecipe)
                    intent.putExtra("isEdit", true)
                    root.context.startActivity(intent)
                }

                imgFvrt.setOnClickListener {
                    toggleFavorite(currentRecipe)
                }

                btnDelete.setOnClickListener {
                    showDeleteConfirmationDialog(currentRecipe)
                }

                updateFavoriteUI(currentRecipe)
            }
        }

        binding.btnPlay.setOnClickListener {
            videoUri?.let { uri ->
                binding.videoView.apply {
                    setVideoURI(uri)
                    start()
                    isVideoPlaying = true
                    isGyroscopeActive = true
                }
            }
        }

        binding.btnPause.setOnClickListener {
            binding.videoView.apply {
                if (isPlaying) {
                    pause()
                    isVideoPlaying = false
                    isGyroscopeActive = false
                }
            }
        }
    }

    private fun updateFavoriteUI(recipe: Recipe) {
        binding.let {
            val repository = RecipeRepository(application)
            val isFavourite = repository.isFavourite(recipe.id ?: "")
            val color = if (isFavourite) R.color.accent else R.color.black
            it.imgFvrt.setColorFilter(ContextCompat.getColor(this, color))
        }
    }

    private fun toggleFavorite(recipe: Recipe) {
        val repository = RecipeRepository(application)
        val recipeId = recipe.id ?: return
        val isFavourite = repository.isFavourite(recipeId)
        if (isFavourite) {
            repository.delete(FavouriteRecipe(recipeId))
            animateFavoriteRemoved()
            Toast.makeText(this, "Removed from favorites", Toast.LENGTH_SHORT).show()
        } else {
            repository.insert(FavouriteRecipe(recipeId))
            animateFavoriteAdded()
            Toast.makeText(this, "Added to favorites", Toast.LENGTH_SHORT).show()
        }
        updateFavoriteUI(recipe)
    }

    private fun animateFavoriteAdded() {
        val animation = AnimationUtils.loadAnimation(this, R.anim.heart_pulse)
        binding.imgFvrt.startAnimation(animation)
    }

    private fun animateFavoriteRemoved() {
        val animation = AnimationUtils.loadAnimation(this, R.anim.heart_shrink)
        binding.imgFvrt.startAnimation(animation)
    }

    private fun showDeleteConfirmationDialog(recipe: Recipe) {
        AlertDialog.Builder(this)
            .setTitle("Delete Recipe")
            .setMessage("Are you sure you want to delete this recipe?")
            .setPositiveButton("Yes") { _, _ ->
                deleteRecipe(recipe)
            }
            .setNegativeButton("No") { dialogInterface, _ -> dialogInterface.dismiss() }
            .show()
    }

    private fun deleteRecipe(recipe: Recipe) {
        val dialog = ProgressDialog(this)
        dialog.setMessage("Deleting...")
        dialog.setCancelable(false)
        dialog.show()

        val reference = FirebaseDatabase.getInstance().getReference("Recipes")
        recipe.id?.let {
            reference.child(it).removeValue()
                .addOnCompleteListener { task: Task<Void?> ->
                    dialog.dismiss()
                    if (task.isSuccessful) {
                        Toast.makeText(
                            this,
                            "Recipe Deleted Successfully",
                            Toast.LENGTH_SHORT
                        ).show()
                        finish()
                    } else {
                        Toast.makeText(this, "Failed to delete recipe", Toast.LENGTH_SHORT)
                            .show()
                    }
                }
        }
    }

    private fun fetchVideoFromFirebaseStorage(videoUrl: String) {
        Log.d("RecipeDetailsActivity", "Video URL: $videoUrl")
        if (videoUrl.isNotBlank()) {
            val storage = FirebaseStorage.getInstance()
            val storageRef = storage.getReferenceFromUrl(videoUrl)

            val localFile = File.createTempFile("video", "mp4")
            storageRef.getFile(localFile).addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    videoUri = Uri.fromFile(localFile)
                } else {
                    Log.e("RecipeDetailsActivity", "Error downloading video: ${task.exception}")
                }
            }
        } else {
            Log.e("RecipeDetailsActivity", "Error: videoUrl is null or empty")
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        binding.videoView.stopPlayback()
        isGyroscopeActive = false
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        if (sensor == null) return

        when (sensor.type) {
            Sensor.TYPE_ACCELEROMETER -> {
                Log.d("SensorAccuracy", "Accelerometer accuracy changed to: $accuracy")
            }
            Sensor.TYPE_MAGNETIC_FIELD -> {
                Log.d("SensorAccuracy", "Magnetometer accuracy changed to: $accuracy")
            }
            else -> {
                Log.d("SensorAccuracy", "Accuracy of sensor ${sensor.type} changed to: $accuracy")
            }
        }
    }


    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null || !isVideoPlaying) return
        if (event.sensor.type == Sensor.TYPE_ACCELEROMETER) {
            val values = event.values
            val gravity = FloatArray(3)
            val magnetic = FloatArray(3)
            val rotationMatrix = FloatArray(9)

            SensorManager.getRotationMatrix(rotationMatrix, null, gravity, magnetic)
            val orientation = FloatArray(3)
            SensorManager.getOrientation(rotationMatrix, orientation)
            val pitch = Math.toDegrees(orientation[1].toDouble()).toFloat()
            val roll = Math.toDegrees(orientation[2].toDouble()).toFloat()
            Log.d("SensorOrientation", "Pitch: $pitch, Roll: $roll")

            // Add this log to check sensor values
            Log.d("SensorValues", "X: ${values[0]}, Y: ${values[1]}, Z: ${values[2]}")

            updateVideoOrientation(pitch, roll)
        }
    }


    private fun updateVideoOrientation(pitch: Float, roll: Float) {
        Log.d("VideoOrientation", "Pitch: $pitch, Roll: $roll")
        if (pitch > 45 && pitch < 135) {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            binding.videoView.layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        } else if (pitch > -135 && pitch < -45) {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE
            binding.videoView.layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        } else if (roll > 45 && roll < 135) {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            binding.videoView.layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        } else if (roll > -135 && roll < -45) {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_REVERSE_PORTRAIT
            binding.videoView.layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
    }
}
