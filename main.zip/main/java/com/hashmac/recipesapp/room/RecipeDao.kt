package com.hashmac.recipesapp.room

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.hashmac.recipesapp.models.FavouriteRecipe

@Dao
interface RecipeDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(recipe: FavouriteRecipe): Long


    @Query("DELETE FROM favourite_recipes WHERE recipeId = :recipeId")
    fun delete(recipeId: String)


    @Query("SELECT * FROM favourite_recipes WHERE recipeId = :recipeId")
    fun getFavourite(recipeId: String): FavouriteRecipe?



    @Query("SELECT * FROM favourite_recipes")
    fun getAllFavourites(): List<FavouriteRecipe>
}
