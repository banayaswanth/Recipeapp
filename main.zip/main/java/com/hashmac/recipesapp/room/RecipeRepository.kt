package com.hashmac.recipesapp.room

import android.app.Application
import com.hashmac.recipesapp.models.FavouriteRecipe
import com.hashmac.recipesapp.room.RecipeDatabase.Companion.getInstance
import java.util.concurrent.ExecutionException

class RecipeRepository(application: Application?) {
    private val recipeDao: RecipeDao?

    init {
        val database = getInstance(application!!)
        recipeDao = database?.favouriteDao()
    }

    fun insert(recipe: FavouriteRecipe): Long {
        return try {
            RecipeDatabase.databaseWriteExecutor.submit<Long> {
                recipeDao?.insert(recipe)
            }.get() ?: -1
        } catch (e: InterruptedException) {
            e.printStackTrace()
            Thread.currentThread().interrupt()
            -1
        } catch (e: ExecutionException) {
            e.printStackTrace()
            -1
        }
    }

    fun delete(recipe: FavouriteRecipe) {
        RecipeDatabase.databaseWriteExecutor.submit {
            recipeDao?.delete(recipe.recipeId)
        }
    }

    fun isFavourite(favouriteRecipe: String): Boolean {
        return try {
            RecipeDatabase.databaseWriteExecutor.submit<Boolean> {
                recipeDao?.getFavourite(favouriteRecipe) != null
            }.get() ?: false
        } catch (e: InterruptedException) {
            e.printStackTrace()
            Thread.currentThread().interrupt()
            false
        } catch (e: ExecutionException) {
            e.printStackTrace()
            false
        }
    }

    val allFavourites: List<FavouriteRecipe>
        get() {
            val future = RecipeDatabase.databaseWriteExecutor.submit<List<FavouriteRecipe>> {
                recipeDao?.getAllFavourites() ?: emptyList()
            }
            return try {
                future.get()
            } catch (e: InterruptedException) {
                e.printStackTrace()
                Thread.currentThread().interrupt()
                emptyList()
            } catch (e: ExecutionException) {
                e.printStackTrace()
                emptyList()
            }
        }
}
