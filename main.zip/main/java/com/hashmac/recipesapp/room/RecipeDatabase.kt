package com.hashmac.recipesapp.room

import android.content.Context
import androidx.room.Database
import androidx.room.Room.databaseBuilder
import androidx.room.RoomDatabase
import com.hashmac.recipesapp.models.FavouriteRecipe
import java.util.concurrent.Executors

@Database(entities = [FavouriteRecipe::class], version = 2 , exportSchema = false)
abstract class RecipeDatabase : RoomDatabase() {
    abstract fun favouriteDao(): RecipeDao?

    companion object {
        var instance: RecipeDatabase? = null
        private const val NUMBER_OF_THREADS = 4
        @JvmField
        val databaseWriteExecutor = Executors.newFixedThreadPool(NUMBER_OF_THREADS)
        @JvmStatic
        @Synchronized
        fun getInstance(context: Context): RecipeDatabase? {
            if (instance == null) {
                instance = databaseBuilder(
                    context.applicationContext,
                    RecipeDatabase::class.java,
                    "recipe_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
            }
            return instance
        }
    }
}
