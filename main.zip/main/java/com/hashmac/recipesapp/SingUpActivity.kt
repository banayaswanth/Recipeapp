package com.hashmac.recipesapp

import android.app.ProgressDialog
import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.tasks.OnCompleteListener
import com.google.android.gms.tasks.Task
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.AuthResult
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.hashmac.recipesapp.databinding.ActivitySingUpBinding
import com.hashmac.recipesapp.models.User
import java.util.Objects

class SingUpActivity : AppCompatActivity() {
    var binding: ActivitySingUpBinding? = null
    var dialog: ProgressDialog? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySingUpBinding.inflate(layoutInflater)
        setContentView(binding!!.root)
        binding!!.btnSignup.setOnClickListener { view: View? -> signup() }

    }

    private fun signup() {
        val name = Objects.requireNonNull(binding!!.etName.text).toString().trim { it <= ' ' }
        val email = Objects.requireNonNull(binding!!.etEmail.text).toString().trim { it <= ' ' }
        val password =
            Objects.requireNonNull(binding!!.etPassword.text).toString().trim { it <= ' ' }
        if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter your name, email and password", Toast.LENGTH_SHORT)
                .show()
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(this, "Please enter a valid email address", Toast.LENGTH_SHORT).show()
        } else if (password.length < 6) {
            Toast.makeText(this, "Password must be at least 6 characters", Toast.LENGTH_SHORT)
                .show()
        } else {
            // let's create a new user in the Firebase
            createNewUser(name, email, password)
        }
    }

    private fun createNewUser(name: String, email: String, password: String) {

        dialog = ProgressDialog(this)
        dialog!!.setMessage("Creating user...")
        dialog!!.setCancelable(false)
        dialog!!.show()
        FirebaseApp.initializeApp(this)
        val auth = FirebaseAuth.getInstance()
        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener { task: Task<AuthResult?> ->
                if (task.isSuccessful) {
                    // user account created successfully
                    saveName(name, email)
                } else {
                    // account creation failed
                    dialog!!.dismiss()
                    Toast.makeText(this, "Account creation failed", Toast.LENGTH_SHORT).show()
                }
            }
    }

    private fun saveName(name: String, email: String) {
        val reference = FirebaseDatabase.getInstance().getReference("Users")
        val user = User(FirebaseAuth.getInstance().uid, name, email, "", "")
        reference.child(Objects.requireNonNull(FirebaseAuth.getInstance().uid)!!).setValue(user)
            .addOnCompleteListener(object : OnCompleteListener<Void?> {
                override fun onComplete(p0: Task<Void?>) {
                    if (p0.isComplete) {
                        dialog!!.dismiss()
                         Toast.makeText(
                            this@SingUpActivity,
                            "User created successfully",
                            Toast.LENGTH_SHORT
                        ).show()
                        startActivity(Intent(this@SingUpActivity, MainActivity::class.java))
                        finishAffinity()
                    } else {
                        dialog!!.dismiss()
                        Toast.makeText(
                            this@SingUpActivity,
                            "Failed to create user",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            })
    }
}