package com.hashmac.recipesapp.models

class User {
    var id: String? = null
    @JvmField
    var name: String? = null
    @JvmField
    var email: String? = null
    @JvmField
    var image: String? = null
    @JvmField
    var cover: String? = null

    constructor()
    constructor(id: String?, name: String?, email: String?, image: String?, cover: String?) {
        this.id = id
        this.name = name
        this.email = email
        this.image = image
        this.cover = cover
    }
}
