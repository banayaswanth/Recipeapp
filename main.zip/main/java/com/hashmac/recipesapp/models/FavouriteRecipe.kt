package com.hashmac.recipesapp.models

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "favourite_recipes")
class FavouriteRecipe(@JvmField var recipeId: String) {
    @PrimaryKey(autoGenerate = true)
    var id: Long = 0

}
