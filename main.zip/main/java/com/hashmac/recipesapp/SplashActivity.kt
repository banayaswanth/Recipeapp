package com.hashmac.recipesapp

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.hashmac.recipesapp.databinding.ActivitySplashBinding


@SuppressLint("CustomSplashScreen")
class SplashActivity : AppCompatActivity() {
    private val splashScreenTime = 1000 // 3 seconds
    private val timeInterval = 100 // 0.1 seconds
    private var progress = 0 // 0 to 100 for progress bar
    private var runnable: Runnable? = null
    private var handler: Handler? = null
    private var binding: ActivitySplashBinding? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySplashBinding.inflate(layoutInflater) // View Binding for Splash Screen
        setContentView(binding!!.root)
        binding!!.progressBar.max = splashScreenTime // set max value for progress bar
        binding!!.progressBar.progress = progress // set initial value for progress bar
        handler = Handler(Looper.getMainLooper()) // create handler
        runnable = Runnable {
            // This code will check splash screen time completed or not
            if (progress < splashScreenTime) {
                progress += timeInterval
                binding!!.progressBar.progress = progress
                handler!!.postDelayed(runnable!!, timeInterval.toLong())
            } else {
                // This code will check user is logged in or not
                FirebaseApp.initializeApp(this)
                val user = FirebaseAuth.getInstance().currentUser
                // if user is logged in
                // if user is not logged in (user is null
                startActivity(
                    if (user != null) Intent(
                        this@SplashActivity,
                        MainActivity::class.java
                    ) else Intent(this@SplashActivity, LoginActivity::class.java)
                )
                finish()
            }
        }
        handler!!.postDelayed(runnable!!, timeInterval.toLong()) // start handler
    }
}