package com.hashmac.recipesapp.fragment

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.hashmac.recipesapp.R
import com.hashmac.recipesapp.adapters.RecipeAdapter
import com.hashmac.recipesapp.databinding.FragmentFavouritesBinding
import com.hashmac.recipesapp.models.Recipe
import com.hashmac.recipesapp.room.RecipeRepository


class FavouritesFragment : Fragment() {
    var binding: FragmentFavouritesBinding? = null
    var recipeRepository: RecipeRepository? = null
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentFavouritesBinding.inflate(inflater, container, false)
        return binding!!.root
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Apply pulse animation to the fragment content
        val pulseAnimation = AnimationUtils.loadAnimation(requireContext(), R.anim.pulse)
        binding!!.rvFavourites.startAnimation(pulseAnimation)
    }

    override fun onResume() {
        super.onResume()
        loadFavorites()
    }

    private fun loadFavorites() {
        recipeRepository = RecipeRepository(requireActivity().application)
        val favouriteRecipes = recipeRepository!!.allFavourites
        if (favouriteRecipes!!.isEmpty()) {
            Toast.makeText(requireContext(), "No Favourites", Toast.LENGTH_SHORT).show()
            binding!!.rvFavourites.visibility = View.GONE
            binding!!.noFavourites.visibility = View.VISIBLE
        } else {
            binding!!.rvFavourites.layoutManager = GridLayoutManager(requireContext(), 2)
            binding!!.rvFavourites.adapter = RecipeAdapter(requireContext())
            val recipes: MutableList<Recipe?> = ArrayList()
            val reference = FirebaseDatabase.getInstance().getReference("Recipes")
            reference.addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.hasChildren()) {
                        for (dataSnapshot in snapshot.children) {
                            for (favouriteRecipe in favouriteRecipes) {
                                if (dataSnapshot.key == favouriteRecipe!!.recipeId) {
                                    recipes.add(dataSnapshot.getValue(Recipe::class.java))
                                }
                            }
                        }
                        binding!!.rvFavourites.visibility = View.VISIBLE
                        binding!!.noFavourites.visibility = View.GONE
                        val adapter = binding!!.rvFavourites.adapter as RecipeAdapter?
                        adapter?.setRecipeList(recipes)
                    } else {
                        binding!!.noFavourites.visibility = View.VISIBLE
                        binding!!.rvFavourites.visibility = View.GONE
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Log.e("FavouritesFragment", "onCancelled: " + error.message)
                }
            })
        }
    }
}