package com.hashmac.recipesapp.fragment

import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import android.view.inputmethod.EditorInfo
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.hashmac.recipesapp.AllRecipesActivity
import com.hashmac.recipesapp.R
import com.hashmac.recipesapp.adapters.HorizontalRecipeAdapter
import com.hashmac.recipesapp.databinding.FragmentHomeBinding
import com.hashmac.recipesapp.models.Recipe
import java.util.*

class HomeFragment : Fragment() {
    private var binding: FragmentHomeBinding? = null
    private lateinit var speechRecognizer: SpeechRecognizer
    private val REQUEST_CODE_SPEECH_INPUT = 1

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding!!.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Initialize SpeechRecognizer
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(requireContext())
        val ivMic: ImageView = view.findViewById(R.id.iv_mic)


        binding!!.etSearch.setOnEditorActionListener { textView: TextView?, i: Int, keyEvent: KeyEvent? ->
            if (i == EditorInfo.IME_ACTION_SEARCH) {
                performSearch()
                return@setOnEditorActionListener true
            }
            false
        }

        binding!!.ivMic.setOnClickListener {
            startVoiceInput()
        }

        binding!!.tvSeeAllFavourite.setOnClickListener {
            val intent = Intent(requireContext(), AllRecipesActivity::class.java)
            intent.putExtra("type", "favourite")
            startActivity(intent)
        }

        binding!!.tvSeeAllPopulars.setOnClickListener {
            val intent = Intent(requireContext(), AllRecipesActivity::class.java)
            intent.putExtra("type", "popular")
            startActivity(intent)
        }

        loadRecipes()
    }

    private fun startVoiceInput() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        intent.putExtra(
            RecognizerIntent.EXTRA_LANGUAGE_MODEL,
            RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
        )
        intent.putExtra(
            RecognizerIntent.EXTRA_LANGUAGE,
            Locale.getDefault()
        )
        intent.putExtra(
            RecognizerIntent.EXTRA_PROMPT,
            "Speak something..."
        )
        try {
            startActivityForResult(intent, REQUEST_CODE_SPEECH_INPUT)
        } catch (e: ActivityNotFoundException) {
            Log.e("Error", e.message!!)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        when (requestCode) {
            REQUEST_CODE_SPEECH_INPUT -> {
                if (resultCode == -1 && data != null) {
                    val result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                    val spokenText = result?.get(0)
                    binding!!.etSearch.setText(spokenText)
                }
            }
        }
    }

    private fun performSearch() {
        val query = binding!!.etSearch.text.toString().trim()
        val intent = Intent(requireContext(), AllRecipesActivity::class.java)
        intent.putExtra("type", "search")
        intent.putExtra("query", query)
        startActivity(intent)
    }

    private fun loadRecipes() {
        binding!!.rvPopulars.adapter = HorizontalRecipeAdapter(requireContext())
        binding!!.rvFavouriteMeal.adapter = HorizontalRecipeAdapter(requireContext())
        val reference = FirebaseDatabase.getInstance().getReference("Recipes")
        reference.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val recipes: MutableList<Recipe?> = ArrayList()
                for (dataSnapshot in snapshot.children) {
                    val recipe = dataSnapshot.getValue(Recipe::class.java)
                    recipes.add(recipe)
                }
                loadPopularRecipes(recipes)
                loadFavouriteRecipes(recipes)
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("Error", error.message)
            }
        })
    }
    private fun loadPopularRecipes(recipes: List<Recipe?>) {
        val popularRecipes: MutableList<Recipe> = ArrayList()
        if (recipes.isNotEmpty()) {
            for (i in 0..4) {
                val random = (Math.random() * recipes.size).toInt()
                recipes[random]?.let {
                    popularRecipes.add(it)
                }
            }

        }
        val adapter = binding!!.rvPopulars.adapter as HorizontalRecipeAdapter?
        adapter?.setRecipeList(popularRecipes)

        // Apply animation to the RecyclerView
        val animation = AnimationUtils.loadAnimation(requireContext(), R.anim.fade_out_animation)
        binding!!.rvPopulars.startAnimation(animation)
    }


    private fun loadFavouriteRecipes(recipes: List<Recipe?>) {
        val favouriteRecipes: MutableList<Recipe> = ArrayList()
        if (recipes.isNotEmpty()) {
            for (i in 0..4) {
                val random = (Math.random() * recipes.size).toInt()
                recipes[random]?.let {
                    favouriteRecipes.add(it)
                }
            }
        }
        val adapter = binding!!.rvFavouriteMeal.adapter as HorizontalRecipeAdapter?
        adapter?.setRecipeList(favouriteRecipes)
        val animation = AnimationUtils.loadAnimation(requireContext(), R.anim.fade_out_animation)
        binding!!.rvFavouriteMeal.startAnimation(animation)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        binding = null
    }
}
