package com.hashmac.recipesapp.fragment

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.firebase.database.*
import com.hashmac.recipesapp.adapters.CategoryAdapter
import com.hashmac.recipesapp.databinding.FragmentCategoryBinding
import com.hashmac.recipesapp.models.Category


class CategoriesFragment : Fragment() {

    private var _binding: FragmentCategoryBinding? = null
    private val binding get() = _binding!!
    private lateinit var categoryAdapter: CategoryAdapter
    private lateinit var databaseReference: DatabaseReference

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentCategoryBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        categoryAdapter = CategoryAdapter()
        binding.rvCategories.apply {
            adapter = categoryAdapter
            layoutManager = LinearLayoutManager(requireContext())


        }
        databaseReference = FirebaseDatabase.getInstance().getReference("Recipes")
        loadCategoriesFromFirebase()
        val animation = AnimationUtils.loadAnimation(requireContext(), com.hashmac.recipesapp.R.anim.slide_from_bottom)
        binding!!.rvCategories.startAnimation(animation)

    }


    private fun loadCategoriesFromFirebase() {
        databaseReference.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val categories: MutableSet<String> = mutableSetOf()
                for (dataSnapshot in snapshot.children) {
                    val category = dataSnapshot.child("category").getValue(String::class.java)
                    category?.let { categories.add(it) }
                }
                val categoryList = categories.toList().sorted() // Sort categories alphabetically
                val categoryObjects = categoryList.map { Category(null, it, null) }
                categoryAdapter.setCategoryList(categoryObjects)
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("CategoriesFragment", "Error loading categories: ${error.message}")
            }
        })
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}