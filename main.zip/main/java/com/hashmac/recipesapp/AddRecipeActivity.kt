package com.hashmac.recipesapp

import android.app.Activity
import android.app.ProgressDialog
import android.content.Intent
import android.location.Geocoder
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import com.hashmac.recipesapp.databinding.ActivityAddRecipeBinding
import com.hashmac.recipesapp.models.Recipe
import java.io.IOException

class AddRecipeActivity : AppCompatActivity() {

    private var binding: ActivityAddRecipeBinding? = null
    private var isImageSelected = false
    private var isVideoSelected = false
    private var dialog: ProgressDialog? = null
    private var imageUrl: String? = null
    private var videoUrl: String? = null
    private var latitude: Double = 0.0
    private var longitude: Double = 0.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddRecipeBinding.inflate(layoutInflater)
        setContentView(binding!!.root)

        val categories = listOf(
            "Breakfast", "Lunch", "Dinner", "Dessert",
            "Vegetarian", "Italian", "Mexican",
        )

        loadCategories(categories)

        binding!!.btnAddRecipe.setOnClickListener {
            addRecipe()
        }

        binding!!.imgRecipe.setOnClickListener {
            pickImage()
        }

        binding!!.btnUploadVideo.setOnClickListener {
            pickVideo()
        }
    }

    private fun loadCategories(categories: List<String>) {
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, categories)
        binding?.etCategory?.setAdapter(adapter)
    }

    private fun pickImage() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(intent, REQUEST_PICK_IMAGE)
    }

    private fun pickVideo() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(intent, REQUEST_PICK_VIDEO)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == REQUEST_PICK_IMAGE) {
                val imageUri: Uri? = data?.data
                if (imageUri != null) {
                    imageUrl = imageUri.toString()
                    isImageSelected = true
                    binding?.imgRecipe?.setImageURI(imageUri)
                }
            } else if (requestCode == REQUEST_PICK_VIDEO) {
                val videoUri: Uri? = data?.data
                if (videoUri != null) {
                    videoUrl = videoUri.toString()
                    isVideoSelected = true
                }
            }
        }
    }

    private fun addRecipe() {
        val recipeName = binding?.etRecipeName?.text.toString()
        val recipeDescription = binding?.etDescription?.text.toString()
        val cookingTime = binding?.etCookingTime?.text.toString()
        val recipeCategory = binding?.etCategory?.text.toString()
        val calories = binding?.etCalories?.text.toString()
        val region = binding?.etRegion?.text.toString()

        if (recipeName.isEmpty() || recipeDescription.isEmpty() || cookingTime.isEmpty() ||
            recipeCategory.isEmpty() || calories.isEmpty() || region.isEmpty() ||
            !isImageSelected || !isVideoSelected) {
            Toast.makeText(this, "Please fill all fields and select an image, video, and region", Toast.LENGTH_SHORT).show()
            return
        }

        dialog = ProgressDialog(this)
        dialog!!.setMessage("Adding Recipe...")
        dialog!!.setCancelable(false)
        dialog!!.show()

        // Convert region name to latitude and longitude
        getLatLngFromRegion(region)

        // Proceed with uploading image and video
        uploadImageAndVideo(recipeName, recipeDescription, cookingTime, recipeCategory, calories)
    }

    private fun getLatLngFromRegion(regionName: String) {
        // Implement geocoding service to get latitude and longitude from region name
        // For demonstration purposes, you can replace this with your preferred geocoding implementation
        // Here we are using Geocoder class to perform geocoding
        val geocoder = Geocoder(this)
        try {
            val addresses = geocoder.getFromLocationName(regionName, 1)
            if (addresses != null && addresses.isNotEmpty()) {
                val address = addresses[0]
                latitude = address.latitude
                longitude = address.longitude
            } else {
                // Handle case when no location is found for the given region name
                Toast.makeText(this, "Location not found for the given region name", Toast.LENGTH_SHORT).show()
            }
        } catch (e: IOException) {
            e.printStackTrace()
            // Handle IO exception
            Toast.makeText(this, "Error fetching location data", Toast.LENGTH_SHORT).show()
        }
    }

    private fun uploadImageAndVideo(
        recipeName: String,
        recipeDescription: String,
        cookingTime: String,
        recipeCategory: String,
        calories: String
    ) {
        val storage = FirebaseStorage.getInstance()
        val imageStorageRef = storage.reference.child("images/${System.currentTimeMillis()}_recipe.jpg")
        val videoStorageRef = storage.reference.child("videos/${System.currentTimeMillis()}_recipe.mp4")

        // Upload image to Firebase Storage
        imageStorageRef.putFile(Uri.parse(imageUrl))
            .continueWithTask { task ->
                if (!task.isSuccessful) {
                    throw task.exception!!
                }
                imageStorageRef.downloadUrl
            }
            .addOnCompleteListener { imageUploadTask ->
                if (imageUploadTask.isSuccessful) {
                    val imageDownloadUri = imageUploadTask.result
                    imageUrl = imageDownloadUri.toString()

                    // Upload video to Firebase Storage
                    videoStorageRef.putFile(Uri.parse(videoUrl))
                        .continueWithTask { task ->
                            if (!task.isSuccessful) {
                                throw task.exception!!
                            }
                            videoStorageRef.downloadUrl
                        }
                        .addOnCompleteListener { videoUploadTask ->
                            if (videoUploadTask.isSuccessful) {
                                val videoDownloadUri = videoUploadTask.result
                                videoUrl = videoDownloadUri.toString()

                                // Save recipe details with image and video URLs to Firebase Realtime Database
                                val recipe = Recipe(
                                    recipeName,
                                    latitude,
                                    longitude,
                                    recipeDescription,
                                    cookingTime,
                                    recipeCategory,
                                    calories,
                                    imageUrl!!,
                                    FirebaseAuth.getInstance().uid!!,
                                    videoUrl!!
                                )
                                saveRecipeToDatabase(recipe)
                            } else {
                                dialog?.dismiss()
                                Toast.makeText(this, "Error uploading video", Toast.LENGTH_SHORT).show()
                                Log.e(TAG, "Error uploading video: ${videoUploadTask.exception?.message}")
                            }
                        }
                } else {
                    dialog?.dismiss()
                    Toast.makeText(this, "Error uploading image", Toast.LENGTH_SHORT).show()
                    Log.e(TAG, "Error uploading image: ${imageUploadTask.exception?.message}")
                }
            }
    }

    private fun saveRecipeToDatabase(recipe: Recipe) {
        val reference = FirebaseDatabase.getInstance().reference.child("Recipes")
        val recipeId = reference.push().key ?: ""
        recipe.id = recipeId

        reference.child(recipeId).setValue(recipe)
            .addOnSuccessListener {
                dialog?.dismiss()
                Toast.makeText(this, "Recipe added successfully", Toast.LENGTH_SHORT).show()
                finish()
            }
            .addOnFailureListener { e ->
                dialog?.dismiss()
                Log.e(TAG, "Error adding recipe to database", e)
                Toast.makeText(this, "Error adding recipe", Toast.LENGTH_SHORT).show()
            }
    }

    companion object {
        private const val TAG = "AddRecipeActivity"
        private const val REQUEST_PICK_IMAGE = 101
        private const val REQUEST_PICK_VIDEO = 102
        private const val REQUEST_GEOCODING = 103
    }
}
