package com.hashmac

class yas {
}