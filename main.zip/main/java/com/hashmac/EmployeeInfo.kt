package com.hashmac


data class EmployeeInfo
    (
    var empId: String? = null,
    var empName:String? = null,
    var empMail:String? = null,
    var empPass:String? = null,
)